import { PortfolioData, StrapiConfig } from './types';
import { mockPortfolioData } from './data';

const STORAGE_KEY = 'portfolio_strapi_config';

export const defaultStrapiConfig: StrapiConfig = {
  baseUrl: 'http://localhost:1337', // Strapi Default Port
  apiToken: '',
  useMock: true,
};

// Retrieve configuration from LocalStorage
export function getStrapiConfig(): StrapiConfig {
  const stored = localStorage.getItem(STORAGE_KEY);
  if (!stored) return defaultStrapiConfig;
  try {
    return JSON.parse(stored);
  } catch {
    return defaultStrapiConfig;
  }
}

// Save configuration to LocalStorage
export function saveStrapiConfig(config: StrapiConfig): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
}

/**
 * Safely extracts attributes and data fields from Strapi API JSON formats
 * Supports both Strapi v4 (nested attributes) and Strapi v5 (flattened fields).
 */
function parseStrapiItem(item: any): any {
  if (!item) return null;
  
  // If it's wrapped in attributes (Strapi v4)
  if (item.attributes) {
    return {
      id: item.id,
      ...item.attributes,
    };
  }
  return item;
}

function parseStrapiCollection(response: any): any[] {
  if (!response) return [];
  const data = response.data || response;
  if (!Array.isArray(data)) return [];
  return data.map(parseStrapiItem);
}

/**
 * Main function to fetch portfolio data.
 * If Strapi is enabled and configured, it attempts to query individual endpoints.
 * Includes fallback logic to load standard Mock Data if query fails or is set to Mock.
 */
export async function fetchPortfolioData(config: StrapiConfig): Promise<{ data: PortfolioData; source: 'strapi' | 'mock'; error?: string }> {
  if (config.useMock) {
    return { data: mockPortfolioData, source: 'mock' };
  }

  const headers: HeadersInit = {
    'Content-Type': 'application/json',
  };

  if (config.apiToken) {
    headers['Authorization'] = `Bearer ${config.apiToken}`;
  }

  try {
    // We expect 5 separate schemas or a single unified "portfolio" schema.
    // To make it incredibly robust, we will fetch from: 
    // - Profile endpoint: /api/profile
    // - Skills endpoint: /api/skills
    // - Education endpoint: /api/educations
    // - Experiences endpoint: /api/experiences
    // - Socials endpoint: /api/socials
    // If any of these fail, we throw a descriptive error or look for a unified endpoint.
    
    const baseUrl = config.baseUrl.replace(/\/$/, ''); // strip trailing slash

    // Run parallel fetch calls to replicate a fully functioning decoupled frontend
    const [profileRes, skillsRes, educationsRes, experiencesRes, socialsRes] = await Promise.all([
      fetch(`${baseUrl}/api/profile?populate=*`, { headers }).then(r => r.ok ? r.json() : null),
      fetch(`${baseUrl}/api/skills?pagination[limit]=100&populate=*`, { headers }).then(r => r.ok ? r.json() : null),
      fetch(`${baseUrl}/api/educations?sort=duration:desc&populate=*`, { headers }).then(r => r.ok ? r.json() : null),
      fetch(`${baseUrl}/api/experiences?sort=duration:desc&populate=*`, { headers }).then(r => r.ok ? r.json() : null),
      fetch(`${baseUrl}/api/socials?populate=*`, { headers }).then(r => r.ok ? r.json() : null),
    ]);

    // Check if at least we got profile or some data
    if (!profileRes && !skillsRes && !educationsRes && !experiencesRes) {
      throw new Error("No se pudo obtener datos de Strapi (endpoints vacíos o errores 404). Verifica que Strapi esté activo, tus endpoints creados y los permisos públicos configurados en Ajustes > Roles > Public.");
    }

    // Map profile data
    const rawProfile = profileRes?.data ? parseStrapiItem(profileRes.data) : null;
    const profile = rawProfile ? {
      name: rawProfile.name || mockPortfolioData.profile.name,
      role: rawProfile.role || mockPortfolioData.profile.role,
      description: rawProfile.description || mockPortfolioData.profile.description,
      longDescription: rawProfile.longDescription || mockPortfolioData.profile.longDescription,
      avatarUrl: rawProfile.avatar?.url 
        ? `${baseUrl}${rawProfile.avatar.url}` 
        : rawProfile.avatarUrl || mockPortfolioData.profile.avatarUrl,
      resumeUrl: rawProfile.resume?.url 
        ? `${baseUrl}${rawProfile.resume.url}` 
        : rawProfile.resumeUrl || mockPortfolioData.profile.resumeUrl,
      email: rawProfile.email || mockPortfolioData.profile.email,
      location: rawProfile.location || mockPortfolioData.profile.location,
      status: rawProfile.status || mockPortfolioData.profile.status,
    } : mockPortfolioData.profile;

    // Map skills
    const rawSkills = parseStrapiCollection(skillsRes);
    const skills = rawSkills.length > 0 ? rawSkills.map(s => ({
      name: s.name,
      category: s.category || 'Frontend',
      level: s.level || 80,
      icon: s.icon || 'Code2',
    })) : mockPortfolioData.skills;

    // Map education
    const rawEducations = parseStrapiCollection(educationsRes);
    const education = rawEducations.length > 0 ? rawEducations.map(e => ({
      institution: e.institution,
      degree: e.degree,
      duration: e.duration,
      description: e.description,
      credentialUrl: e.credentialUrl,
      type: e.type || 'education',
    })) : mockPortfolioData.education;

    // Map experience
    const rawExperiences = parseStrapiCollection(experiencesRes);
    const experience = rawExperiences.length > 0 ? rawExperiences.map(exp => ({
      company: exp.company,
      role: exp.role,
      duration: exp.duration,
      description: Array.isArray(exp.description) 
        ? exp.description 
        : typeof exp.description === 'string' 
          ? exp.description.split('\n').filter((l: string) => l.trim().length > 0)
          : [exp.description],
      skills: Array.isArray(exp.skills) 
        ? exp.skills 
        : typeof exp.skills === 'string' 
          ? exp.skills.split(',').map((s: string) => s.trim())
          : [],
    })) : mockPortfolioData.experience;

    // Map socials
    const rawSocials = parseStrapiCollection(socialsRes);
    const socials = rawSocials.length > 0 ? rawSocials.map(soc => ({
      platform: (soc.platform || 'github').toLowerCase() as any,
      url: soc.url,
      label: soc.label || soc.platform,
    })) : mockPortfolioData.socials;

    return {
      data: { profile, socials, skills, education, experience },
      source: 'strapi'
    };
  } catch (err: any) {
    console.warn('Strapi Fetch Error, falling back to Mock:', err);
    return {
      data: mockPortfolioData,
      source: 'mock',
      error: err.message || 'Error de conexión con Strapi Api.'
    };
  }
}

/**
 * Tests connection to a Strapi URL.
 */
export async function testStrapiConnection(config: StrapiConfig): Promise<{ success: boolean; message: string }> {
  try {
    const baseUrl = config.baseUrl.replace(/\/$/, '');
    const headers: HeadersInit = { 'Content-Type': 'application/json' };
    if (config.apiToken) {
      headers['Authorization'] = `Bearer ${config.apiToken}`;
    }
    
    // Check main Strapi API root or standard endpoint
    const res = await fetch(`${baseUrl}/api/profile`, { headers });
    if (res.ok) {
      return { success: true, message: 'Conexión exitosa. El endpoint /api/profile fue accedido correctamente.' };
    }
    
    const generalRes = await fetch(`${baseUrl}/admin`, { method: 'HEAD' });
    if (generalRes.ok) {
      return { success: true, message: 'Se contactó el servidor Strapi, pero el endpoint /api/profile devolvió código ' + res.status + '. Asegúrate de configurar permisos públicos o proveer un Token válido.' };
    }
    
    throw new Error(`Código de respuesta: ${res.status}`);
  } catch (err: any) {
    return { success: false, message: `Error de conexión: ${err.message || 'Verifica que el host y puerto estén activos y permitan tráfico CORS.'}` };
  }
}
